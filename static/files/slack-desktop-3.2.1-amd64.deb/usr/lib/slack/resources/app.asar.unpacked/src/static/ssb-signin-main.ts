import { overrideWindowOpen } from '../ssb/override-window-open';
import { WebContentsChannel } from '../utils/ipc-channel-names';

if (window.location.href !== 'about:blank') {
  // The lightest of all preload scripts
  const ipcRenderer = require('electron').ipcRenderer;

  (window as any).winssb = {
    app: {
      didFinishLoading() {
        ipcRenderer.send(WebContentsChannel.DidFinishLoading);
      }
    },

    teams: {
      didSignIn(...args: Array<any>) {
        ipcRenderer.send(WebContentsChannel.DidSignIn, ...args);
      }
    }
  };

  /**
   * Block drag & drop on the sign-in window only. We can't block window
   * navigation at the WebContents level because of SSO / customer auth pages.
   */
  if (document) {
    document.addEventListener('dragover', (e) => e.preventDefault());
    document.addEventListener('drop', (e) => e.preventDefault());
  }

  overrideWindowOpen((opts) => window.winssb.window.open(opts));
  window.desktop = window.winssb;
}
